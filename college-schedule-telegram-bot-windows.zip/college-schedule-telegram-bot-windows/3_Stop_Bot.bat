@echo off
title Stop Telegram Bot
cd /d "%~dp0"

echo ================================================================
echo    Stopping Telegram Bot on port 3000...
echo ================================================================
echo.

set FOUND=0
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    echo [INFO] Terminating PID %%a...
    taskkill /f /pid %%a >nul 2>&1
    set FOUND=1
)

if "%FOUND%"=="1" (
    echo [SUCCESS] Bot process stopped successfully.
) else (
    echo [INFO] No active bot process found on port 3000.
)

echo ================================================================
pause
