@echo off
chcp 65001 >nul
title Остановка Telegram-бота КБК
cd /d "%~dp0"

echo ================================================================
echo    КБК • Остановка Telegram-бота
echo ================================================================
echo.

set FOUND=0
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    echo [INFO] Завершаем процесс с PID %%a на порту 3000...
    taskkill /f /pid %%a >nul 2>&1
    set FOUND=1
)

if "%FOUND%"=="1" (
    echo [OK] Бот успешно остановлен.
) else (
    echo [INFO] Запущенный процесс бота на порту 3000 не найден.
)

echo ================================================================
pause
