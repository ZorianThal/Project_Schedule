Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c 2_Start_Bot.bat", 0, False
Set WshShell = Nothing
MsgBox "Telegram-bot started in background!" & vbCrLf & "Web interface: http://localhost:3000" & vbCrLf & vbCrLf & "To stop, run 3_Stop_Bot.bat", 64, "KBK Bot"
