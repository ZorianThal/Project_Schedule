@echo off
title KBK Schedule Bot - Setup Dependencies
cd /d "%~dp0"

echo ================================================================
echo    KBK College Schedule Telegram Bot - Setup
echo ================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is NOT installed on this computer!
    echo.
    echo Please download and install Node.js (LTS version) from:
    echo https://nodejs.org/
    echo.
    echo After installing, restart this script.
    echo ================================================================
    pause
    exit /b 1
)

echo [OK] Node.js is installed.
echo [INFO] Running npm install... Please wait a moment...
echo.

call npm install

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

echo.
echo ================================================================
echo [SUCCESS] Dependencies installed successfully!
echo You can now start the bot using 2_Start_Bot.bat
echo ================================================================
pause
