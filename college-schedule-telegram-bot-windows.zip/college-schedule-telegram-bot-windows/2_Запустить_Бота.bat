@echo off
chcp 65001 >nul
title Telegram-бот расписания КБК (@SugiSai_bot)
cd /d "%~dp0"

echo ================================================================
echo    КБК • Telegram-бот расписания (@SugiSai_bot)
echo ================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Node.js не найден!
    echo Установите Node.js с https://nodejs.org/ и перезапустите файл.
    pause
    exit /b 1
)

:: Проверка наличия node_modules
if not exist "node_modules\" (
    echo [INFO] Папка node_modules не найдена. Устанавливаем зависимости...
    call npm install
    if %errorlevel% neq 0 (
        echo [ОШИБКА] Не удалось установить зависимости.
        pause
        exit /b 1
    )
)

:: Проверка .env
if not exist ".env" (
    if exist ".env.example" (
        echo [INFO] Создаем .env из шаблона .env.example...
        copy .env.example .env >nul
    )
)

echo.
echo ================================================================
echo [ЗАПУСК] Сервер и Telegram-бот запускаются...
echo          • Веб-интерфейс: http://localhost:3000
echo          • Telegram-бот:  @SugiSai_bot
echo          • Для остановки: закройте это окно или нажмите Ctrl+C
echo ================================================================
echo.

call npm run dev
pause
