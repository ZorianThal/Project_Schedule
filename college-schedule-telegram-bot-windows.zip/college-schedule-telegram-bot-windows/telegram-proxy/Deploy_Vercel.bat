@echo off
title Deploy Telegram Proxy to Vercel
cd /d "%~dp0"

echo ================================================================
echo    Deploy Telegram Bot Reverse Proxy to Vercel
echo ================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is NOT installed!
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

echo [INFO] Starting Vercel deployment...
echo If this is your first time, Vercel will open a browser window to login.
echo On each setup prompt, just press ENTER to accept default options.
echo.
pause

call npx vercel --prod

echo.
echo ================================================================
echo [SUCCESS] Copy your Production URL (e.g. https://...vercel.app)
echo and paste it into your bot .env file:
echo TELEGRAM_API_BASE="https://your-app.vercel.app"
echo ================================================================
pause
