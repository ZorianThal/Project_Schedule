# Telegram Bot API Reverse Proxy for Vercel

Быстрый и надежный реверс-прокси для Telegram Bot API на Vercel Edge Network.
Позволяет Telegram-ботам работать в России без VPN и без блокировок.

## Развертывание в Vercel

### Вариант 1. Через терминал (1 команда):
```bash
cd "/Users/rei/Desktop/Рабочая папка/КБК/telegram-proxy"
npx vercel
```
Следуйте простым подсказкам на экране:
1. `Set up and deploy?` -> `Y`
2. `Which scope?` -> Выберите свой аккаунт
3. `Link to existing project?` -> `N`
4. `Project name?` -> `telegram-proxy` (или любое другое)
5. `In which directory is your code located?` -> `.` (Enter)

После деплоя Vercel выдаст ссылку вида:
`https://telegram-proxy-xxx.vercel.app`

### Вариант 2. Через GitHub:
1. Создайте пустой репозиторий на GitHub.
2. Запушьте эту папку.
3. На [vercel.com](https://vercel.com) нажмите **Add New Project** -> выберите репозиторий -> нажмите **Deploy**.

## Использование в боте

В файле `.env` вашего бота укажите:
```env
TELEGRAM_API_BASE="https://telegram-proxy-xxx.vercel.app"
```
*(без слеша на конце)*
