@echo off
title Telegram Bot KBK (@SugiSai_bot)
cd /d "%~dp0"

echo ================================================================
echo    KBK College Schedule Telegram Bot (@SugiSai_bot)
echo ================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is NOT installed!
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

if not exist "node_modules\" (
    echo [INFO] node_modules not found. Installing dependencies...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm install failed.
        pause
        exit /b 1
    )
)

if not exist ".env" (
    if exist ".env.example" (
        echo [INFO] Creating .env from .env.example...
        copy .env.example .env >nul
    )
)

echo.
echo ================================================================
echo [OK] Starting Telegram Bot and Web Server...
echo      - Web Interface: http://localhost:3000
echo      - Telegram Bot:  @SugiSai_bot
echo      - To stop: close this window or press Ctrl+C
echo ================================================================
echo.

call npm run dev
pause
