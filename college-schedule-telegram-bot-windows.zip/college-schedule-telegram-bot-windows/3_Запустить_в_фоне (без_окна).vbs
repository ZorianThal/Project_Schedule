Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c 2_Запустить_Бота.bat", 0, False
Set WshShell = Nothing
MsgBox "Telegram-бот КБК запущен в фоновом режиме!" & vbCrLf & "Веб-интерфейс доступен по адресу: http://localhost:3000" & vbCrLf & vbCrLf & "Для остановки запустите файл '4_Остановить_бота.bat'", 64, "КБК • Telegram-бот"
